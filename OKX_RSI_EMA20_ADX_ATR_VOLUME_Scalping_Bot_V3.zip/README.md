# OKX RSI + EMA20 + ADX + ATR + Volume Scalping Bot V3

## Chart / signal display
The included TradingView Pine Script (`RSI_EMA20_ADX_ATR_VOLUME_OKX.pine`) displays:
- BUY / SELL markers directly on the price chart
- Entry price
- SL price
- TP price
- Signal source: RSI crossover or EMA20
- ADX value
- EMA20 line

## Signal hierarchy
1. RSI14/RSI100 crossover is the primary signal.
2. If there is no RSI crossover, EMA20 reclaim/rejection can provide an alternative scalp signal.
3. ADX, volume and ATR are confirmation filters.
4. 15-minute EMA20 trend confirmation is enabled by default.
5. Only confirmed candles are processed.

## Default filters
- ADX >= 18
- Current volume >= 0.8 × 20-candle average volume
- ATR >= 0.05% of price
- 15m trend must agree with the trade
These are configurable in `.env`.

## Trading settings
- OKX Demo = true
- Margin = $20
- Leverage = 5x
- Approx target notional = $100, subject to contract sizing
- Isolated margin
- SL = 0.4%
- TP = 0.8%
- 5m entries
- 15m trend confirmation
- BTC, ETH, XRP, DOGE

## Setup
1. Install Python 3.10+.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Enter your OKX DEMO API credentials only in `.env`.
5. Run `python bot.py`.
6. Open `/health` to verify settings.

Do not share or commit `.env`.

## TradingView
The Pine script is for visual confirmation/alerts. The Python bot can independently calculate the same core signals from OKX candles, so TradingView is not required for execution.

## Risk note
These filters can reduce low-quality trades but do not guarantee profitability. Test thoroughly in OKX Demo before considering live trading.
