import os, time, json, hmac, base64, hashlib
from decimal import Decimal, ROUND_DOWN
from datetime import datetime, timezone
import requests
from flask import Flask, request, jsonify
from dotenv import load_dotenv

load_dotenv()

BASE_URL=os.getenv("OKX_BASE_URL","https://www.okx.com")
API_KEY=os.getenv("OKX_API_KEY","")
SECRET_KEY=os.getenv("OKX_SECRET_KEY","")
PASSPHRASE=os.getenv("OKX_PASSPHRASE","")
DEMO=os.getenv("OKX_DEMO","true").lower()=="true"
WEBHOOK_TOKEN=os.getenv("WEBHOOK_TOKEN","change-me")

BAR=os.getenv("BAR","5m")
TREND_BAR=os.getenv("TREND_BAR","15m")
POLL_SECONDS=int(os.getenv("POLL_SECONDS","15"))

MARGIN_USDT=Decimal(os.getenv("MARGIN_USDT","20"))
LEVERAGE=Decimal(os.getenv("LEVERAGE","5"))
TD_MODE=os.getenv("TD_MODE","isolated")

RSI_FAST=int(os.getenv("RSI_FAST","14"))
RSI_SLOW=int(os.getenv("RSI_SLOW","100"))
EMA_PERIOD=int(os.getenv("EMA_PERIOD","20"))

SL_PERCENT=Decimal(os.getenv("SL_PERCENT","0.4"))
TP_PERCENT=Decimal(os.getenv("TP_PERCENT","0.8"))

EMA_MODE=os.getenv("EMA_MODE","true").lower()=="true"
EMA_BUY_RSI_MAX=Decimal(os.getenv("EMA_BUY_RSI_MAX","55"))
EMA_SELL_RSI_MIN=Decimal(os.getenv("EMA_SELL_RSI_MIN","45"))

# Confirmation filters
USE_ADX=os.getenv("USE_ADX","true").lower()=="true"
ADX_PERIOD=int(os.getenv("ADX_PERIOD","14"))
ADX_MIN=Decimal(os.getenv("ADX_MIN","18"))

USE_VOLUME=os.getenv("USE_VOLUME","true").lower()=="true"
VOLUME_PERIOD=int(os.getenv("VOLUME_PERIOD","20"))
VOLUME_MULT=Decimal(os.getenv("VOLUME_MULT","0.8"))

USE_ATR=os.getenv("USE_ATR","true").lower()=="true"
ATR_PERIOD=int(os.getenv("ATR_PERIOD","14"))
ATR_MIN_PCT=Decimal(os.getenv("ATR_MIN_PCT","0.05"))

USE_15M_TREND=os.getenv("USE_15M_TREND","true").lower()=="true"

SYMBOLS=[s.strip() for s in os.getenv(
    "SYMBOLS","BTC-USDT-SWAP,ETH-USDT-SWAP,XRP-USDT-SWAP,DOGE-USDT-SWAP"
).split(",") if s.strip()]

session=requests.Session()
app=Flask(__name__)
instrument_cache={}
last_candle={}
last_signal={}

def utc_iso():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00","Z")

def sign(ts,method,path,body=""):
    msg=ts+method.upper()+path+body
    return base64.b64encode(hmac.new(SECRET_KEY.encode(),msg.encode(),hashlib.sha256).digest()).decode()

def private_request(method,path,payload=None,params=None):
    if not API_KEY or not SECRET_KEY or not PASSPHRASE:
        raise RuntimeError("OKX API credentials are missing in .env")
    body=json.dumps(payload,separators=(",",":")) if payload else ""
    ts=utc_iso()
    headers={
        "Content-Type":"application/json",
        "OK-ACCESS-KEY":API_KEY,
        "OK-ACCESS-SIGN":sign(ts,method,path,body),
        "OK-ACCESS-PASSPHRASE":PASSPHRASE,
        "OK-ACCESS-TIMESTAMP":ts
    }
    if DEMO: headers["x-simulated-trading"]="1"
    r=session.request(method,BASE_URL+path,headers=headers,json=payload,params=params,timeout=15)
    r.raise_for_status()
    data=r.json()
    if data.get("code")!="0": raise RuntimeError(f"OKX {data.get('code')}: {data.get('msg')}")
    return data

def public_get(path,params=None):
    r=session.get(BASE_URL+path,params=params,timeout=15)
    r.raise_for_status()
    data=r.json()
    if data.get("code")!="0": raise RuntimeError(f"OKX {data.get('code')}: {data.get('msg')}")
    return data

def get_instrument(inst_id):
    if inst_id in instrument_cache: return instrument_cache[inst_id]
    rows=public_get("/api/v5/public/instruments",{"instType":"SWAP","instId":inst_id})["data"]
    if not rows: raise RuntimeError(f"Instrument not found: {inst_id}")
    x=rows[0]
    info={"ctVal":Decimal(x["ctVal"]),"ctValCcy":x["ctValCcy"],
          "lotSz":Decimal(x["lotSz"]),"minSz":Decimal(x["minSz"]),
          "tickSz":Decimal(x["tickSz"])}
    instrument_cache[inst_id]=info
    return info

def round_down(v,step):
    return (v/step).to_integral_value(rounding=ROUND_DOWN)*step if step>0 else v

def get_candles(inst_id,bar=BAR,limit=160):
    rows=public_get("/api/v5/market/candles",
                    {"instId":inst_id,"bar":bar,"limit":str(limit)})["data"]
    out=[]
    for x in reversed(rows):
        out.append({"ts":int(x[0]),"open":Decimal(x[1]),"high":Decimal(x[2]),
                    "low":Decimal(x[3]),"close":Decimal(x[4]),
                    "volume":Decimal(x[5]),"confirm":x[8] if len(x)>8 else "1"})
    return out

def rsi_series(vals,p):
    out=[None]*len(vals)
    if len(vals)<=p:return out
    gains=[];losses=[]
    for i in range(1,len(vals)):
        d=vals[i]-vals[i-1];gains.append(max(d,Decimal("0")));losses.append(max(-d,Decimal("0")))
    ag=sum(gains[:p],Decimal("0"))/Decimal(p);al=sum(losses[:p],Decimal("0"))/Decimal(p)
    def rv(g,l): return Decimal("100") if l==0 else Decimal("100")-Decimal("100")/(Decimal("1")+g/l)
    out[p]=rv(ag,al)
    for j in range(p,len(gains)):
        ag=((ag*Decimal(p-1))+gains[j])/Decimal(p)
        al=((al*Decimal(p-1))+losses[j])/Decimal(p)
        out[j+1]=rv(ag,al)
    return out

def ema_series(vals,p):
    out=[None]*len(vals)
    if len(vals)<p:return out
    k=Decimal("2")/Decimal(p+1);e=sum(vals[:p],Decimal("0"))/Decimal(p);out[p-1]=e
    for i in range(p,len(vals)):
        e=vals[i]*k+e*(Decimal("1")-k);out[i]=e
    return out

def atr_series(c,p):
    out=[None]*len(c)
    if len(c)<=p:return out
    tr=[None]
    for i in range(1,len(c)):
        tr.append(max(c[i]["high"]-c[i]["low"],
                      abs(c[i]["high"]-c[i-1]["close"]),
                      abs(c[i]["low"]-c[i-1]["close"])))
    a=sum(tr[1:p+1],Decimal("0"))/Decimal(p);out[p]=a
    for i in range(p+1,len(c)):
        a=((a*Decimal(p-1))+tr[i])/Decimal(p);out[i]=a
    return out

def adx_series(c,p):
    # Wilder-style ADX approximation, suitable as a filter.
    n=len(c);out=[None]*n
    if n<2*p+1:return out
    trs=[None]*n; plus=[None]*n; minus=[None]*n
    for i in range(1,n):
        up=c[i]["high"]-c[i-1]["high"];down=c[i-1]["low"]-c[i]["low"]
        trs[i]=max(c[i]["high"]-c[i]["low"],
                   abs(c[i]["high"]-c[i-1]["close"]),
                   abs(c[i]["low"]-c[i-1]["close"]))
        plus[i]=up if up>down and up>0 else Decimal("0")
        minus[i]=down if down>up and down>0 else Decimal("0")
    atr=sum(trs[1:p+1],Decimal("0"))/Decimal(p)
    pg=sum(plus[1:p+1],Decimal("0"))/Decimal(p)
    mg=sum(minus[1:p+1],Decimal("0"))/Decimal(p)
    dx=[]
    for i in range(p,n):
        if i>p:
            atr=((atr*Decimal(p-1))+trs[i])/Decimal(p)
            pg=((pg*Decimal(p-1))+plus[i])/Decimal(p)
            mg=((mg*Decimal(p-1))+minus[i])/Decimal(p)
        pdi=Decimal("100")*pg/atr if atr else Decimal("0")
        mdi=Decimal("100")*mg/atr if atr else Decimal("0")
        den=pdi+mdi
        dx.append((Decimal("100")*abs(pdi-mdi)/den) if den else Decimal("0"))
        if len(dx)>=p:
            out[i]=sum(dx[-p:],Decimal("0"))/Decimal(p)
    return out

def trend_direction(c):
    x=[z for z in c if z["confirm"]=="1"]
    if len(x)<EMA_PERIOD+2:return None
    closes=[z["close"] for z in x]
    e=ema_series(closes,EMA_PERIOD);i=len(x)-1
    if e[i] is None:return None
    if closes[i]>e[i] and e[i]>e[i-1]:return "bull"
    if closes[i]<e[i] and e[i]<e[i-1]:return "bear"
    return "flat"

def filter_state(c):
    x=[z for z in c if z["confirm"]=="1"]
    if len(x)<max(RSI_SLOW,EMA_PERIOD,VOLUME_PERIOD,ATR_PERIOD,ADX_PERIOD)+5:return None
    closes=[z["close"] for z in x];i=len(x)-1
    r14=rsi_series(closes,RSI_FAST);r100=rsi_series(closes,RSI_SLOW);ema=ema_series(closes,EMA_PERIOD)
    atr=atr_series(x,ATR_PERIOD);adx=adx_series(x,ADX_PERIOD)
    if any(v[i] is None for v in (r14,r100,ema,atr,adx)):return None

    vol_ok=True
    if USE_VOLUME:
        avg=sum(z["volume"] for z in x[-(VOLUME_PERIOD+1):-1],Decimal("0"))/Decimal(VOLUME_PERIOD)
        vol_ok=x[-1]["volume"]>=avg*VOLUME_MULT

    atr_ok=True
    if USE_ATR:
        atr_pct=(atr[i]/closes[i])*Decimal("100")
        atr_ok=atr_pct>=ATR_MIN_PCT

    adx_ok=(not USE_ADX) or adx[i]>=ADX_MIN
    return {"r14":r14[i],"r100":r100[i],"ema":ema[i],"adx":adx[i],
            "atr":atr[i],"volume_ok":vol_ok,"atr_ok":atr_ok,"adx_ok":adx_ok,
            "close":closes[i],"prev_close":closes[i-1],"prev_ema":ema[i-1],
            "ema_slope":ema[i]-ema[i-1]}

def calculate_signal(candles,trend15=None):
    x=[z for z in candles if z["confirm"]=="1"]
    if len(x)<max(RSI_SLOW,EMA_PERIOD,VOLUME_PERIOD,ATR_PERIOD,ADX_PERIOD)+5:return None
    closes=[z["close"] for z in x];i=len(x)-1
    r14=rsi_series(closes,RSI_FAST);r100=rsi_series(closes,RSI_SLOW);ema=ema_series(closes,EMA_PERIOD)
    adx=adx_series(x,ADX_PERIOD);atr=atr_series(x,ATR_PERIOD)
    if any(v[i] is None or v[i-1] is None for v in (r14,r100,ema)):return None

    # Primary RSI crossover
    raw=None
    if r14[i-1]<=r100[i-1] and r14[i]>r100[i]: raw=("buy","RSI_CROSS")
    elif r14[i-1]>=r100[i-1] and r14[i]<r100[i]: raw=("sell","RSI_CROSS")

    # Alternative EMA20 reclaim/rejection
    if raw is None and EMA_MODE:
        if closes[i-1]<=ema[i-1] and closes[i]>ema[i] and r14[i]<=EMA_BUY_RSI_MAX:
            raw=("buy","EMA20_RECLAIM")
        elif closes[i-1]>=ema[i-1] and closes[i]<ema[i] and r14[i]>=EMA_SELL_RSI_MIN:
            raw=("sell","EMA20_REJECTION")

    if raw is None:return None
    signal,reason=raw

    # Directional 15m confirmation.
    if USE_15M_TREND and trend15 in ("bull","bear"):
        if signal=="buy" and trend15!="bull":return None
        if signal=="sell" and trend15!="bear":return None

    # ADX, volume, ATR filters.
    if USE_ADX and adx[i]<ADX_MIN:return None
    if USE_VOLUME:
        avg=sum(z["volume"] for z in x[-(VOLUME_PERIOD+1):-1],Decimal("0"))/Decimal(VOLUME_PERIOD)
        if x[-1]["volume"]<avg*VOLUME_MULT:return None
    if USE_ATR:
        atr_pct=(atr[i]/closes[i])*Decimal("100")
        if atr_pct<ATR_MIN_PCT:return None

    return {"signal":signal,"reason":reason,"entry":closes[i],
            "rsi14":r14[i],"rsi100":r100[i],"ema20":ema[i],
            "adx":adx[i],"atr":atr[i],"trend15":trend15 or "n/a"}

def get_positions(inst_id):
    rows=private_request("GET","/api/v5/account/positions",params={"instId":inst_id})["data"]
    return [p for p in rows if Decimal(p.get("pos","0"))!=0]

def set_leverage(inst_id):
    return private_request("POST","/api/v5/account/set-leverage",
                           {"instId":inst_id,"lever":str(LEVERAGE),"mgnMode":TD_MODE})

def contract_size(inst_id,entry):
    info=get_instrument(inst_id)
    per=info["ctVal"] if info["ctValCcy"].upper()=="USDT" else info["ctVal"]*entry
    target=MARGIN_USDT*LEVERAGE
    return max(round_down(target/per,info["lotSz"]),info["minSz"])

def open_position(inst_id,sig):
    entry=sig["entry"];info=get_instrument(inst_id);sz=contract_size(inst_id,entry)
    set_leverage(inst_id)
    if sig["signal"]=="buy":
        sl=entry*(Decimal("1")-SL_PERCENT/Decimal("100"));tp=entry*(Decimal("1")+TP_PERCENT/Decimal("100"))
        side="buy";pos="long"
    else:
        sl=entry*(Decimal("1")+SL_PERCENT/Decimal("100"));tp=entry*(Decimal("1")-TP_PERCENT/Decimal("100"))
        side="sell";pos="short"
    sl=round_down(sl,info["tickSz"]);tp=round_down(tp,info["tickSz"])
    payload={"instId":inst_id,"tdMode":TD_MODE,"side":side,"posSide":pos,
             "ordType":"market","sz":str(sz),
             "clOrdId":("v3"+str(int(time.time()*1000)))[-32:],
             "attachAlgoOrds":[{"tpTriggerPx":str(tp),"tpOrdPx":"-1",
                               "tpTriggerPxType":"mark","slTriggerPx":str(sl),
                               "slOrdPx":"-1","slTriggerPxType":"mark"}]}
    res=private_request("POST","/api/v5/trade/order",payload)
    return {"status":"opened","signal":sig["signal"],"reason":sig["reason"],
            "entry":str(entry),"sl":str(sl),"tp":str(tp),"size":str(sz),
            "posSide":pos,"indicators":{k:str(v) for k,v in sig.items() if k not in ("signal","reason")}, "result":res}

def close_position(inst_id,p):
    side="sell" if p["posSide"]=="long" else "buy"
    return private_request("POST","/api/v5/trade/order",
                           {"instId":inst_id,"tdMode":TD_MODE,"side":side,
                            "posSide":p["posSide"],"ordType":"market",
                            "sz":p["pos"],"reduceOnly":"true"})

def execute(inst_id,sig):
    positions=get_positions(inst_id);desired="long" if sig["signal"]=="buy" else "short"
    if any(p["posSide"]==desired for p in positions):
        return {"status":"ignored","message":"Already in desired direction"}
    for p in positions:close_position(inst_id,p)
    return open_position(inst_id,sig)

@app.get("/health")
def health():
    return jsonify({"ok":True,"demo":DEMO,"symbols":SYMBOLS,"bar":BAR,"trend_bar":TREND_BAR,
                    "margin":str(MARGIN_USDT),"leverage":str(LEVERAGE),
                    "sl":str(SL_PERCENT),"tp":str(TP_PERCENT),
                    "adx_min":str(ADX_MIN),"volume_mult":str(VOLUME_MULT),
                    "atr_min_pct":str(ATR_MIN_PCT),"use_15m_trend":USE_15M_TREND})

@app.post("/webhook")
def webhook():
    body=request.get_json(silent=True) or {}
    if body.get("token")!=WEBHOOK_TOKEN:return jsonify({"ok":False,"error":"Unauthorized"}),401
    symbol=body.get("symbol");signal=str(body.get("signal","")).lower()
    if symbol not in SYMBOLS or signal not in ("buy","sell"):
        return jsonify({"ok":False,"error":"Invalid symbol or signal"}),400
    try:
        c=get_candles(symbol,BAR,160);t=trend_direction(get_candles(symbol,TREND_BAR,80))
        s={"signal":signal,"reason":"WEBHOOK","entry":[x for x in c if x["confirm"]=="1"][-1]["close"],
           "rsi14":None,"rsi100":None,"ema20":None,"adx":None,"atr":None,"trend15":t}
        return jsonify(execute(symbol,s))
    except Exception as e:return jsonify({"ok":False,"error":str(e)}),500

def worker():
    print("V3 OKX RSI+EMA20+ADX+ATR+Volume scalping bot started")
    while True:
        for inst in SYMBOLS:
            try:
                c=get_candles(inst,BAR,160);confirmed=[z for z in c if z["confirm"]=="1"]
                if not confirmed:continue
                key=confirmed[-1]["ts"]
                if last_candle.get(inst)==key:continue
                last_candle[inst]=key
                t=trend_direction(get_candles(inst,TREND_BAR,80)) if USE_15M_TREND else None
                sig=calculate_signal(c,t)
                if sig:
                    print(f"{datetime.now()} {inst}: {sig['signal'].upper()} [{sig['reason']}] "
                          f"ADX={sig['adx']} ATR={sig['atr']} Trend15={sig['trend15']}")
                    print(json.dumps(execute(inst,sig),default=str))
            except Exception as e:print(f"[{inst}] ERROR: {e}")
        time.sleep(POLL_SECONDS)

if __name__=="__main__":
    import threading
    threading.Thread(target=worker,daemon=True).start()
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","8080")))
